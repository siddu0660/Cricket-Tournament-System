import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Flag, User } from "lucide-react"

export default function PlayersPage() {
  // Mock data for players
  const players = [
    {
      id: 1,
      firstName: "Virat",
      lastName: "Kohli",
      team: "RCB",
      role: "Batsman",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm medium",
      nationality: "India",
      jerseyNumber: 18,
    },
    {
      id: 2,
      firstName: "Rohit",
      lastName: "Sharma",
      team: "MI",
      role: "Batsman",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm off break",
      nationality: "India",
      jerseyNumber: 45,
    },
    {
      id: 3,
      firstName: "MS",
      lastName: "Dhoni",
      team: "CSK",
      role: "Wicket-keeper",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm medium",
      nationality: "India",
      jerseyNumber: 7,
    },
    {
      id: 4,
      firstName: "Jasprit",
      lastName: "Bumrah",
      team: "MI",
      role: "Bowler",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm fast",
      nationality: "India",
      jerseyNumber: 93,
    },
    {
      id: 5,
      firstName: "Kane",
      lastName: "Williamson",
      team: "SRH",
      role: "Batsman",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm off break",
      nationality: "New Zealand",
      jerseyNumber: 22,
    },
    {
      id: 6,
      firstName: "Jos",
      lastName: "Buttler",
      team: "RR",
      role: "Wicket-keeper",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm medium",
      nationality: "England",
      jerseyNumber: 63,
    },
    {
      id: 7,
      firstName: "Rashid",
      lastName: "Khan",
      team: "SRH",
      role: "Bowler",
      battingStyle: "Right-handed",
      bowlingStyle: "Right-arm leg break",
      nationality: "Afghanistan",
      jerseyNumber: 19,
    },
    {
      id: 8,
      firstName: "Kagiso",
      lastName: "Rabada",
      team: "DC",
      role: "Bowler",
      battingStyle: "Left-handed",
      bowlingStyle: "Right-arm fast",
      nationality: "South Africa",
      jerseyNumber: 25,
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-dark-olive mb-2">Players</h1>
          <p className="text-olive">Manage all cricket players in one place</p>
        </div>
        <Button asChild className="mt-4 md:mt-0 bg-light-teal hover:bg-teal text-dark-olive">
          <Link href="/players/create">Add Player</Link>
        </Button>
      </div>

      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <Input placeholder="Search players..." className="md:max-w-xs" />
          <Select defaultValue="all">
            <SelectTrigger className="md:w-[180px]">
              <SelectValue placeholder="Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="batsman">Batsman</SelectItem>
              <SelectItem value="bowler">Bowler</SelectItem>
              <SelectItem value="all-rounder">All-rounder</SelectItem>
              <SelectItem value="wicket-keeper">Wicket-keeper</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all">
            <SelectTrigger className="md:w-[180px]">
              <SelectValue placeholder="Team" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Teams</SelectItem>
              <SelectItem value="csk">Chennai Super Kings</SelectItem>
              <SelectItem value="mi">Mumbai Indians</SelectItem>
              <SelectItem value="rcb">Royal Challengers Bangalore</SelectItem>
              <SelectItem value="kkr">Kolkata Knight Riders</SelectItem>
              <SelectItem value="dc">Delhi Capitals</SelectItem>
              <SelectItem value="pbks">Punjab Kings</SelectItem>
              <SelectItem value="rr">Rajasthan Royals</SelectItem>
              <SelectItem value="srh">Sunrisers Hyderabad</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="batsmen">Batsmen</TabsTrigger>
          <TabsTrigger value="bowlers">Bowlers</TabsTrigger>
          <TabsTrigger value="all-rounders">All-rounders</TabsTrigger>
          <TabsTrigger value="wicket-keepers">Wicket-keepers</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {players.map((player) => (
              <Card key={player.id} className="border-olive/20 hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 bg-light-teal rounded-full flex items-center justify-center">
                      <User className="h-6 w-6 text-dark-olive" />
                    </div>
                    <div>
                      <CardTitle className="text-dark-olive">
                        {player.firstName} {player.lastName}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1">
                        <span>{player.team}</span>
                        <span className="mx-1">•</span>
                        <span>{player.role}</span>
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Flag className="h-4 w-4 text-olive" />
                      <span>{player.nationality}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-olive">Batting:</span>
                      <span>{player.battingStyle}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-olive">Bowling:</span>
                      <span>{player.bowlingStyle}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-olive">Jersey:</span>
                      <span>#{player.jerseyNumber}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href={`/players/${player.id}`}>View Profile</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="batsmen" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {players
              .filter((p) => p.role === "Batsman")
              .map((player) => (
                <Card key={player.id} className="border-olive/20 hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 bg-light-teal rounded-full flex items-center justify-center">
                        <User className="h-6 w-6 text-dark-olive" />
                      </div>
                      <div>
                        <CardTitle className="text-dark-olive">
                          {player.firstName} {player.lastName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1">
                          <span>{player.team}</span>
                          <span className="mx-1">•</span>
                          <span>{player.role}</span>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Flag className="h-4 w-4 text-olive" />
                        <span>{player.nationality}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Batting:</span>
                        <span>{player.battingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Bowling:</span>
                        <span>{player.bowlingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Jersey:</span>
                        <span>#{player.jerseyNumber}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <Link href={`/players/${player.id}`}>View Profile</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="bowlers" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {players
              .filter((p) => p.role === "Bowler")
              .map((player) => (
                <Card key={player.id} className="border-olive/20 hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 bg-light-teal rounded-full flex items-center justify-center">
                        <User className="h-6 w-6 text-dark-olive" />
                      </div>
                      <div>
                        <CardTitle className="text-dark-olive">
                          {player.firstName} {player.lastName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1">
                          <span>{player.team}</span>
                          <span className="mx-1">•</span>
                          <span>{player.role}</span>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Flag className="h-4 w-4 text-olive" />
                        <span>{player.nationality}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Batting:</span>
                        <span>{player.battingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Bowling:</span>
                        <span>{player.bowlingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Jersey:</span>
                        <span>#{player.jerseyNumber}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <Link href={`/players/${player.id}`}>View Profile</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
        <TabsContent value="wicket-keepers" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {players
              .filter((p) => p.role === "Wicket-keeper")
              .map((player) => (
                <Card key={player.id} className="border-olive/20 hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 bg-light-teal rounded-full flex items-center justify-center">
                        <User className="h-6 w-6 text-dark-olive" />
                      </div>
                      <div>
                        <CardTitle className="text-dark-olive">
                          {player.firstName} {player.lastName}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-1">
                          <span>{player.team}</span>
                          <span className="mx-1">•</span>
                          <span>{player.role}</span>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Flag className="h-4 w-4 text-olive" />
                        <span>{player.nationality}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Batting:</span>
                        <span>{player.battingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Bowling:</span>
                        <span>{player.bowlingStyle}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-olive">Jersey:</span>
                        <span>#{player.jerseyNumber}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <Link href={`/players/${player.id}`}>View Profile</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

