import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { Trophy, Users, Clock } from "lucide-react"

export default function TeamsPage() {
  // Mock data for teams
  const teams = [
    {
      id: 1,
      name: "Chennai Super Kings",
      shortName: "CSK",
      owner: "Chennai Super Kings Cricket Ltd.",
      since: 2008,
      titles: 4,
      players: 25,
    },
    {
      id: 2,
      name: "Mumbai Indians",
      shortName: "MI",
      owner: "Indiawin Sports Pvt. Ltd.",
      since: 2008,
      titles: 5,
      players: 25,
    },
    {
      id: 3,
      name: "Royal Challengers Bangalore",
      shortName: "RCB",
      owner: "Royal Challengers Sports Pvt. Ltd.",
      since: 2008,
      titles: 0,
      players: 25,
    },
    {
      id: 4,
      name: "Kolkata Knight Riders",
      shortName: "KKR",
      owner: "Knight Riders Sports Pvt. Ltd.",
      since: 2008,
      titles: 2,
      players: 25,
    },
    {
      id: 5,
      name: "Delhi Capitals",
      shortName: "DC",
      owner: "GMR Sports Pvt. Ltd. & JSW Sports Pvt. Ltd.",
      since: 2008,
      titles: 0,
      players: 25,
    },
    {
      id: 6,
      name: "Punjab Kings",
      shortName: "PBKS",
      owner: "KPH Dream Cricket Pvt. Ltd.",
      since: 2008,
      titles: 0,
      players: 25,
    },
    {
      id: 7,
      name: "Rajasthan Royals",
      shortName: "RR",
      owner: "Royal Multisport Pvt. Ltd.",
      since: 2008,
      titles: 1,
      players: 25,
    },
    {
      id: 8,
      name: "Sunrisers Hyderabad",
      shortName: "SRH",
      owner: "SUN TV Network",
      since: 2013,
      titles: 1,
      players: 25,
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-dark-olive mb-2">Teams</h1>
          <p className="text-olive">Manage all cricket teams in one place</p>
        </div>
        <Button asChild className="mt-4 md:mt-0 bg-light-teal hover:bg-teal text-dark-olive">
          <Link href="/teams/create">Create Team</Link>
        </Button>
      </div>

      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <Input placeholder="Search teams..." className="md:max-w-xs" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {teams.map((team) => (
          <Card key={team.id} className="border-olive/20 hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 bg-light-teal rounded-full flex items-center justify-center">
                  <span className="font-bold text-dark-olive">{team.shortName}</span>
                </div>
                <div>
                  <CardTitle className="text-dark-olive">{team.name}</CardTitle>
                  <CardDescription>{team.owner}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-olive" />
                  <span>Since {team.since}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-olive" />
                  <span>{team.titles} Titles</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-olive" />
                  <span>{team.players} Players</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href={`/teams/${team.id}`}>View Details</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

